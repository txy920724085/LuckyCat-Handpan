set root [file dirname [file normalize [info script]]]
set h [open [file join $root video rtl asset_paths.vh] w]
foreach {macro name} {PAN_ROM_FILE handpan.hex UI_ROM_FILE ui_bytes.hex HANN_ROM_FILE hann1024.hex TW_RE_FILE twiddle_re.hex TW_IM_FILE twiddle_im.hex BAND_END_FILE band_ends.hex} {
 puts $h [format {`define %s "../../video/assets/%s"} $macro $name]
}
close $h
create_project -name handpan_visual -dir [file join $root build] -pn GW5AST-LV138FPG676AC1/I0 -device_version B -force
foreach f {
common_rtl/reset_sync.v
common_rtl/sine_lut.v
common_rtl/adsr_envelope.v
common_rtl/dds_glide_voice.v
common_rtl/handpan_glide_voice.v
common_rtl/handpan_glide_poly.v
common_rtl/pitch_slew.v
common_rtl/uart_glide_control.v
common_rtl/pt8211_tx.v
common_rtl/i2s_tx.v
common_rtl/uart_rx.v
common_rtl/audio_echo.v
common_rtl/audio_gain.v
common_rtl/uart_telemetry_top.v
common_rtl/performance_leds.v
common_rtl/uart_visual_top.v
common_rtl/unsigned_div49.v
common_rtl/handpan_tdm_bank.v
common_rtl/sine_interp.v
common_rtl/audio_dc_block.v
common_rtl/uart_tx.v
common_rtl/performance_telemetry.v
common_rtl/zone_note_map.v
common_rtl/velocity_map.v
common_rtl/sensor_event_adapter.v
common_rtl/event_arbiter.v
common_rtl/ads8688_spi_frame.v
common_rtl/ads8688_stream.sv
common_rtl/knock_detector.sv
rtl/sustain_param_rom.v
rtl/drum_sustain_rom.v
rtl/qt_sustain_adapter.v
rtl/ks_shared_bank.v
rtl/i2c_bit.sv
rtl/i2c_register.sv
rtl/qt2120_controller.sv
rtl/qt_key_control.v
rtl/qt_key_telemetry.v
rtl/uart_echo_control.v
rtl/modal_v3_tdm_bank.v
rtl/hybrid_poly.v
rtl/uart_timbre_queue.v
rtl/uart_hybrid_top.v
rtl/dual_uart_command_rx.v
rtl/jdy_uart_tx.sv
rtl/qt_sustain_telemetry.v
rtl/jdy_uart_rx.sv
rtl/jdy_frame_rx.sv
rtl/jdy_block_transport.sv
rtl/sensor_diag_capture_jdy31.sv
rtl/hit_telemetry.v
rtl/pmr1_telemetry.v
rtl/telemetry_frame_mux.v
rtl/ads8688_hybrid_top.v
rtl/handpan_sensor_qt_sustain_drum_top.v
rtl/sensor_crosstalk_filter.sv
rtl/sensor_late_cross_guard.sv
rtl/tune_control.sv
rtl/tune_frame_mux.sv
video/rtl/video_timing.v
video/rtl/reset_sync.v
video/rtl/video_clocks.v
video/rtl/music_visualizer.v
video/rtl/dvi_output.v
video/rtl/pcm_fft_visual.sv
video/rtl/visual_bridge.sv
video/rtl/handpan_visual_top.sv
video/vendor/svo_tmds.v
video/ip/video_pll/Video_PLL/Video_PLL.v
video/ip/video_pll/Video_PLL/Video_PLL_mod.v
video/ip/video_pll/pll_init.v
} {add_file [file join $root $f]}
add_file [file join $root constraints handpan_hdmi.cst]
add_file [file join $root constraints handpan_hdmi.sdc]
set_option -top_module handpan_visual_top
set_option -verilog_std sysv2017
set_option -include_path [file join $root video rtl]
set_option -output_base_name handpan_visual
set_option -use_cpu_as_gpio 1
set_option -timing_driven 1
set_option -correct_hold_violation 1
set_option -place_option 2
set_option -route_option 0
set_option -gen_io_cst 1
set_option -gen_verilog_sim_netlist 1
set_option -show_init_in_vo 1
if {[info exists env(HANDPAN_SYNTH_ONLY)] && $env(HANDPAN_SYNTH_ONLY) eq "1"} {
 run syn
} else {
 run all
}
exit
